#include <iostream>
using namespace std;

int main() {
    int number = 42;  
    int guess;
    int attempts = 0;

    cout << "Guess the hidden number between 1 and 100!" << endl;

    do {
        cout << "Enter your guess: ";
        cin >> guess;
        attempts++;

        if (guess < number) {
            cout << "Too low! Try again." << endl;
        } else if (guess > number) {
            cout << "Too high! Try again." << endl;
        } else {
            cout << "Congratulations! You guessed the number in " << attempts << " attempts." << endl;
        }

    } while (guess != number);

    return 0;
}


