#include<iostream>
using namespace std;
int main(){
    int firstnum,secondnum,a,sum=0,sum2=0;
    cout<<"enter the first integer:";
    cin>>firstnum;
    cout<<"enter the second integer:";
    cin>>secondnum;
    int i=1;
    do
    {
        if (i%2!=0){
            cout<<i<<" is odd number";
            cout<<endl;
            a=i*i;
            sum=sum+a;
            cout<<"sum of odd number between first and second number:"<<sum;
            cout<<endl;
        }else
        cout<<i<<" is even num";
        cout<<endl;
        sum2=sum2+i;
        cout<<"sum of even number between first and second number:"<<sum2;
        cout<<endl;
        i++;
    } while(i<=secondnum);
   return 0; 
}