#include <iostream>
using namespace std;
int main() {
    char word[50]; 

    cout << "Enter a word: ";
    cin >> word;
    int k = 0;
    while (word[k] != '\0') { 
        char ch = word[k];
        if (ch >= 'A' && ch <= 'Z') {
            ch = ch - 'A' + 'a';
        }
        if (ch >= 'a' && ch <= 'z') {
            if (ch >= 'a' && ch <= 'c') cout << '2';
            else if (ch >= 'd' && ch <= 'f') cout << '3';
            else if (ch >= 'g' && ch <= 'i') cout << '4';
            else if (ch >= 'j' && ch <= 'l') cout << '5';
            else if (ch >= 'm' && ch <= 'o') cout << '6';
            else if (ch >= 'p' && ch <= 's') cout << '7';
            else if (ch >= 't' && ch <= 'v') cout << '8';
            else if (ch >= 'w' && ch <= 'z') cout << '9';
        }
        else {
            cout << "\nError: Invalid character '" << word[k] << "'. Only letters are allowed.\n";
            return 1; 
        }

        k++;  
    }
    cout << endl;
    return 0;
}
