#include <iostream>
using namespace std;

int main() {
    int first, second, position;

    
    cout << "Enter the first nonnegative number: ";
    cin >> first;
    cout << "Enter the second nonnegative number: ";
    cin >> second;

    if (first < 0 || second < 0 || first > second) {
        cout << "Invalid input! First must be <= second and both nonnegative." << endl;
        return 1;
    }
    cout << "Enter the position of the Fibonacci number (nonnegative integer): ";
    cin >> position;

    if (position < 0) {
        cout << "Invalid position! Must be nonnegative." << endl;
        return 1;
    }
    long long a = 0, b = 1, fib = 0;
    if (position == 0) fib = 0;
    else if (position == 1) fib = 1;
    else {
        for (int i = 2; i <= position; i++) {
            fib = a + b;
            a = b;
            b = fib;
        }
    }

    cout << "Fibonacci number at position " << position << " is: " << fib << endl;

    return 0;
}
