#include <iostream>
using namespace std;

int main() {
    int nValues[] = {3, 5, 10, 50, 100};

    for (int t = 0; t < 5; t++) {
        int n = nValues[t];
        double e= 0.0;

        
        for (int i = n; i >= 1; i--) {
            e= 1.0 / (i + e);
        }

        e += 2; 

        cout << "Approximation of e for n = " << n << " is " << e << endl;
    }

    return 0;
}
