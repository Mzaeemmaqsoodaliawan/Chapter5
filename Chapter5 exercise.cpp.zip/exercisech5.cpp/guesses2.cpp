#include <iostream>
using namespace std;

int main() {
    int hiddenNumber = 42;
    int guess;
    int tries = 0;

    while (tries < 5) {
        cout << "Enter your guess: ";
        cin >> guess;
        tries++;

        if (guess == hiddenNumber) {
            cout << "You win!" << endl;
            return 0;
        }
    }

    cout << "You lose! The number was " << hiddenNumber << "." << endl;
    return 0;
}
