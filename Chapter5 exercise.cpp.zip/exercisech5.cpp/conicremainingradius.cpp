#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main() {
    double R;  
    cout << "Enter the radius of the circular waxed paper: ";
    cin >> R;
    if (R <= 0) {
        cout << "Radius must be positive." << endl;
        return 1;
    }
    double L = (2.0 / 3.0) * M_PI * R;
    cout << fixed << setprecision(2);
    cout << "Length of removed sector for maximum volume " << L << endl;

    return 0;
}
