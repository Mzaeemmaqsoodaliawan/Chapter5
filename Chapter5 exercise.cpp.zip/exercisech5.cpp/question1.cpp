#include<iostream>
using namespace std;
int main(){
    int  num,a,b;
    cout<<"enter a number:";
    cin>>num;
    while(b>0){
        b=num%10;
num=num/10;

cout<<b<<"\t";
    } return 0;
}