 #include<iostream>
 using namespace std;
 int main(){
    int num,sum=0;
 int counter = 0; 
while (counter < 5)
{ 
 sum = 0; 
 cout<<"enter a number:";
 cin >> num; 
 while (num != -999) 
 { 
 sum = sum + num; 
 cin>> num; 
 } 
 cout << "Line " << counter<< ": Sum = " << sum << endl; 
 counter++; 
}
return 0;
 }