#include<iostream>
using namespace std;
int main(){
    double  popA,popB,growthrate;
    int year=0;
    cout<<"enter the population of town A:";
    cin>>popA;
    cout<<"enter the population of town B:";
    cin>>popB;
    cout<<"enter the growth rate:";
    cin>>growthrate;
    growthrate=growthrate/100;
    while(popA<popB){
        popA= popA+popA*growthrate;
        year++;
    }
    cout<<"it will take "<<year<<" Yearto reach the population of town b";
    return 0;
}