#include<iostream>
using namespace std;
int main(){
    int num;
    unsigned long factorial=1;
    cout<<"enter the positive number:";
    cin>>num;
    if(num<0){
        cout<<"negative number factorial isnot defined:";
    }else{
        for(int i=1;i<=num;++i){
            factorial*=i;
        }
        cout<<"factorial of "<<num<<"is"<<factorial<<endl;
    }
return 0;
}