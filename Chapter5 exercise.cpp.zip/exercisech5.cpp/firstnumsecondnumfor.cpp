#include<iostream>
using namespace std;
int main(){
    int firstnum,secondnum,a,sum=0,sum2=0;
    cout<<"enter the first number:";
    cin>>firstnum;
    cout<<"enter the second number:";
    cin>>secondnum;
    for(int i=firstnum;i<=secondnum;i++){
        if(i%2!=0){
            cout<<i<<" is odd ";
            cout<<endl;
            a=i*i;
            sum=sum+a;
            cout<<sum<<" = sum of square of odd integer between first and second num:";
            cout<<endl;
        }
        else 
        cout<<i<<" is even";
        sum2=sum2+i;
        cout<<"sum of even number "<<sum2;
        cout<<endl;
    }
    return 0;
}