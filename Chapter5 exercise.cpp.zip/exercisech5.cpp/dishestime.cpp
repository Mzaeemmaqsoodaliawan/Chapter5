#include <iostream>
using namespace std;

int main() {
    int a, b, t;
    cout << "Enter time to prepare the first dish (a): ";
    cin >> a;
    cout << "Enter additional time for each following dish (b): ";
    cin >> b;
    cout << "Enter total available time (t): ";
    cin >> t;

    int totalTime = 0;
    int dishes = 0;

    while (true) {
        int timeForNextDish = a + dishes * b;
        if (totalTime + timeForNextDish > t) {
            break;
        }
        totalTime += timeForNextDish;
        dishes++;
    }

    cout << "Bianca can prepare " << dishes << " dish(es) in " << t << " minutes." << endl;

    return 0;
}
