#include<iostream>
using namespace std;
int main(){
    int i,n,f=0;
    cout<<"enter a number:";
    cin>>n;
    i=2;
    while(i<=n/2){
        if(n%i==0){
            f=1;
            break;
        }
        i++;
    }
    if(f==1)
    cout<<"not prime :";
    else 
    cout<<"prime number";
return 0;
}
