#include <iostream>
using namespace std;

int main() {
    char number[20];  // input number as char array
    cout << "Enter a number (digits only): ";
    cin >> number;

    int count = 0; 
    while (number[count] != '\0' && count < 7) {
        char digit = number[count];

        if (digit < '0' || digit > '9') {
            cout << "\nError: Invalid character '" << digit << "'. Only digits 0-9 allowed.\n";
            return 1;
        }
        char letter;
        switch(digit) {
            case '2': letter = 'A'; break;
            case '3': letter = 'D'; break;
            case '4': letter = 'G'; break;
            case '5': letter = 'J'; break;
            case '6': letter = 'M'; break;
            case '7': letter = 'P'; break;
            case '8': letter = 'T'; break;
            case '9': letter = 'W'; break;
            case '0': letter = '0'; break;  
            case '1': letter = '1'; break; 
        }

        cout << letter;
        if ((count + 1) % 3 == 0 && count != 6) {
            cout << "-";
        }

        count++;
    }

    cout << endl;
    return 0;
}

