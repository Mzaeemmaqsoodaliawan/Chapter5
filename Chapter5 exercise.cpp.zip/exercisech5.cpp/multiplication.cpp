#include <iostream>
#include <iomanip>  
using namespace std;

int main() {
    int r = 5;    //r for rows
    int c = 10;   //c for column

    for (int i = 1; i <= r; i++) {      
        for (int j = 1; j <= c; j++) { 
            cout << setw(4) << i * j;     
        }
        cout << endl;
    }

    return 0;
}
