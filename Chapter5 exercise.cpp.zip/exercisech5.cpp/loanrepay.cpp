#include <iostream>
using namespace std;

int main() {
    double loan, rate, payment;
    cout << "Enter loan amount: ";
    cin >> loan;
    cout << "Enter annual interest rate (in %): ";
    cin >> rate;
    cout << "Enter monthly payment: ";
    cin >> payment;

    double monthlyRate = rate / 12 / 100;
    int months = 0;

    if (payment <= loan * monthlyRate) {
        cout << "Monthly payment is too low! Loan cannot be repaid." << endl;
        return 0;
    }

    while (loan > 0) {
        loan = loan + loan * monthlyRate - payment;
        months++;
    }

    cout << "It will take " << months << " months to repay the loan." << endl;
    return 0;
}
