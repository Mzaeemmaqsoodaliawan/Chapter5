#include <iostream>
using namespace std;

int main() {
    int totalUnits;
    double baseRent, rentIncrease, maintenance;

    // Input
    cout << "Enter total number of units: ";
    cin >> totalUnits;
    cout << "Enter rent to occupy all units: ";
    cin >> baseRent;
    cout << "Enter rent increase that causes one vacant unit: ";
    cin >> rentIncrease;
    cout << "Enter maintenance cost per rented unit: ";
    cin >> maintenance;

    int bestUnits = 0;
    double maxProfit = -1;
    for (int rentedUnits = 0; rentedUnits <= totalUnits; rentedUnits++) {
        int vacantUnits = totalUnits - rentedUnits;
        double currentRent = baseRent + rentIncrease * vacantUnits;
        double profit = rentedUnits * (currentRent - maintenance);

        if (profit > maxProfit) {
            maxProfit = profit;
            bestUnits = rentedUnits;
        }
    }

    cout << "Number of units to rent for maximum profit: " << bestUnits << endl;
    return 0;
}
