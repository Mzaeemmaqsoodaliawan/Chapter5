#include<iostream>
#include<fstream>
using namespace std;
int main()
{
    fstream file;
  file.open("example.txt",ios::out);
  if(!file){
    cout<<"file not opening ";
    return 1;
  }
    string text="this is a simple text";
    file<<text;
      
    file.close();
    
    return 0;
}