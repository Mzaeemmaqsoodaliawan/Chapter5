#include<iostream>
#include<fstream>
using namespace std;
int main()
{
  string name;
  fstream file;
  file.open("example.txt",ios::in);
  while(!file.eof())
 { getline(file,name);   
  cout<<"The name in file:"<<name;
}
  file.close();
  return 0;  
}