#include<iostream>
#include<fstream>

using namespace std;
int countcharacter(string &filename)
{
ifstream file(filename);
char ch;
int count=0;
while(file.get(ch)){
    count++;
}
file.close();
return count;
}
int main(){
    string filename="data.txt";
    int totalchares=countcharacter(filename);
    cout<<"total characters in "<<filename<<" :"<<totalchares<<endl;
    return 0;
}