#include<iostream>
#include<fstream>
#include<cctype>
using namespace std;
int countcharacter(string &filename,char c){
 ifstream file(filename);
char ch;
int count=0;
c=tolower(c);
while(file.get(ch)){
    if (tolower(ch)==c){
        count++; 
    }
file.close();
return count;
}}
int main(){
    string filename="data.txt";
    char c;
    cout<<"Enter the charcter to count:";
    cin>>c;
    int frequency=countcharacter(filename,c);
    cout<<"The character"<<c<<"appears"<<frequency<<"times in file"<<endl;
    return 0;
}