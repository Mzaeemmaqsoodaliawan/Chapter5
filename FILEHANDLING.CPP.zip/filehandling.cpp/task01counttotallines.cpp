#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int countlines(string &filename,char  ignore)
{
ifstream file(filename);
string line;
int count=0;
while(getline(file,line)){
    if(!line.empty()&&line[0]!=ignore)
    count++;
}
file.close();
return count;
}
int main(){
    string filename="data.txt";
    char ignore;
    cout<<"enter the charcter to ignore :";
    cin>>ignore;
    int totallines=countlines(filename,ignore);
    cout<<"total lines in "<<filename<<" :"<<totallines<<"excluding lines starting with"<<ignore<<endl;
    return 0;
}