#include <iostream>
#include <fstream>
using namespace std;

void getStudentDetails(string names[], int ages[], float matric[], float fsc[], float ecat[], int size, int &count) {
    count = 0;
    string choice;

    do {
        if (count >= size) break;

        cout << "\nEnter Student Name: ";
        cin >> names[count];
        cout << "Enter Age: ";
        cin >> ages[count];
        cout << "Enter Matric Marks: ";
        cin >> matric[count];
        cout << "Enter Fsc Marks: ";
        cin >> fsc[count];
        cout << "Enter Ecat Marks: ";
        cin >> ecat[count];

        count++;

        cout << "Do you want to add another student? (Yes/No): ";
        cin >> choice;

    } while (choice == "Yes" || choice == "yes");
}

void saveToFile(string names[], int ages[], float matric[], float fsc[], float ecat[], int count, string fileName) {
    ofstream file(fileName);

    for (int i = 0; i < count; i++) {
        file << names[i] << " " << ages[i] << " " << matric[i] << " " << fsc[i] << " " << ecat[i] << endl;
    }

    file.close();
    cout << "\nStudent details saved to " << fileName << " successfully!" << endl;
}

int main() {
    const int MAX = 100;
    string names[MAX];
    int ages[MAX];
    float matric[MAX], fsc[MAX], ecat[MAX];
    int count;

    getStudentDetails(names, ages, matric, fsc, ecat, MAX, count);
    saveToFile(names, ages, matric, fsc, ecat, count, "student.txt");

    return 0;
}
