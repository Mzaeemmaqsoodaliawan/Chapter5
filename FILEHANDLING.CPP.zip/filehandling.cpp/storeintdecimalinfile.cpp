 #include<iostream>
 #include<fstream>
 using namespace std;
 int main(){
    int i;
    cout<<"Enter an integer:";
    cin>>i;
    fstream file;
   file.open("data.txt",ios::out);
   file<<i<<endl;
   file.close();
   float f;

   cout<<"Enter a decimal number:";
   cin>>f;
   file.open("data.txt",ios::app);
   file<<f<<endl;
   file.close();
   char c;
   cout<<"Enter a character :";
   cin>>c;
   file.open("data.txt",ios::app);
    file<<c;
   file.close();
return 0;
 }