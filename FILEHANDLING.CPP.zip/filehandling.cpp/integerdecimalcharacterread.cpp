#include<iostream>
#include<fstream>
using namespace std;
int main(){
    int i;
    fstream file;
    file.open("data.txt",ios::in);
    file>>i;
    file.close();
    cout<<"The Integer in file:"<< i <<endl;
    float s;
    file.open("data.txt",ios::in);
    file>>s;
    file.close();
      cout<<"The decimal number  in file:"<< s <<endl;  
     char ch;
     file.open("data.txt",ios::in);
     file>>ch;
     file.close();
    cout<<"The character in file:"<< ch <<endl;  
return 0;
}