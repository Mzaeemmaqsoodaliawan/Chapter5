#include<iostream>
using namespace std;
int main()
{


int sum = 0,z,average,newNum;

for (z = 1; z <= 5; z++){
    cout<<"enter new number";
cin >> newNum;
sum = sum + newNum;
}
average = sum / 5;
cout << "The sum is " << sum << endl;
cout << "The average is " << average << endl;
return 0;
}
