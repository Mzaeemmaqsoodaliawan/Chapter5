#include <iostream>
using namespace std;
int main()
{
    for (int i = 10; i >=1; i--)

        cout << "reverse order number :" << i << endl;

    return 0;
}