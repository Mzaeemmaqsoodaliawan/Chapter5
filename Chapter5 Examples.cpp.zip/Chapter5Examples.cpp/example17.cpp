#include <iostream> 
using namespace std; 
int main() 
{
 int counter; 
 int sum;
 int N;
 cout << " Enter the number of positive "<< "integers to be added: "; 
 cin >> N; 
 sum = 0; 
 cout << endl; 
 for (counter = 1; counter <= N; counter++) 
 sum = sum + counter; 
 cout << " The sum of the first " <<sum << " positive integers is " << sum<< endl; 
 return 0; 
} 