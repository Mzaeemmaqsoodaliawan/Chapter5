#include<iostream>
#include<string>
#include<iomanip>
using namespace std;
int main()
{
string name;
int numofvolunteers;
int num_of_boxes_Sold;
int totalnumberofboxsold;
int counter=0;
double costofonebox;
cout<<fixed<<showpoint<<setprecision(2);
cout<<"Enter the number of volunteeers :";
cin>>numofvolunteers;
cout<<endl;
totalnumberofboxsold=0;
while(counter < numofvolunteers)
{
    cout<<"Enter the volunteers  name: "<<endl;
    cin>>name;

    cout<<" the number of box sold"<<endl;
    cin>> num_of_boxes_Sold;
    cout<<endl;
    totalnumberofboxsold=totalnumberofboxsold+num_of_boxes_Sold;
    counter++;
}
cout<<"the total numbers of boxes sold :"<<totalnumberofboxsold<<endl;
cout<<"enter the cost of one box :";
cin>>costofonebox;
cout<<endl;
cout<<"the total money  made by selling "<<"cookies:$"<<totalnumberofboxsold*costofonebox<<endl;
if(counter!=0)
cout<<"the average number of "<<"boxes sold by each  volunters :"<< totalnumberofboxsold/counter <<endl;
else 
cout<<"no input";
return 0;
}