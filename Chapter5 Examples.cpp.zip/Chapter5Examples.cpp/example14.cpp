#include<iostream>
using namespace std;
int main( )
{ int i;
for (i = 2; i < 100; i = 2 * i)
 {cout << i << " "; //output power of 2
cout << endl;
 }
}