#include<iostream>
using namespace std;
int countidentical(int  arr[ ][3],int n){
	int c=0;
	for(int i=0;i<n;++i){
		for(int j=i+1;j<n;++j){
			bool is=true;
			for(int k=0;k<3;++k){
				if(arr[i][k]!=arr[j][k]){
					is=false;
					break;
				}
			}
			if(is){
				c++;
			}
		}
	} 
	return c;
}
int main(){
	int arr[4][3]={{0,0,0},{0,1,2},{0,0,0},{2,1,0}};
	cout<<"COUNT IDENTICAL ROWS"<<countidentical(arr,4)<<endl;

	return 0;
}
