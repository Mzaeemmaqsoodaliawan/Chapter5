#include <iostream>
using namespace std;

class World {
private:
    char grid[5][5]; 
    bool gravityStatus;

public: World() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                grid[i][j] = ' . ';  
            }
        }
        gravityStatus = true;  
    }
    void DisplayWorld() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                cout << grid[i][j] << " ";  
            }
            cout << endl;  
        }
    }
    void SetGravityStatus(bool status) {
        gravityStatus = status;
    }
    void TimeTick() {
        if (!gravityStatus) return; 
        for (int col = 0; col < 5; col++) {
            for (int row = 3; row >= 0; row--) {
                if (grid[row][col] == '#') {
                    int dropRow = row;
                    while (dropRow < 4 && grid[dropRow + 1][col] == ' ') {
                        dropRow++;
                    }
                    if (dropRow != row) {
                        grid[dropRow][col] = '#';  
                        grid[row][col] = ' ';   
                    }
                }
            }
        }
    }
    void AddBlock(int row, int col) {
        grid[row][col] = '#';  
    }
};

int main() {
    World world;


    world.AddBlock(0, 0);
    world.AddBlock(1, 1);
    world.AddBlock(2, 2);
    world.AddBlock(3, 3);
    cout << "Initial World:" << endl;
    world.DisplayWorld();
    cout << endl;
    world.SetGravityStatus(true);
    world.TimeTick();
    cout << "World after 1 time tick with gravity on:" << endl;
    world.DisplayWorld();
    cout << endl;
    world.SetGravityStatus(false);
    world.TimeTick();
    cout << "World after 1 time tick with gravity off (no change):" << endl;
    world.DisplayWorld();

    return 0;
}

