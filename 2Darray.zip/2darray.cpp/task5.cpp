#include<iostream>
using namespace std;
int main(){
    int arr[3][3];
    for(int i=0;i<r;i++){
        for(int j=0;j<3;j++){
            cout<<"Enter the Element in"<<i<<j<<endl;
            cin>>arr[i][j];
            if(arr[i]==arr[j]){
                if
            }
        }
    }
    cout<<"The Total sum is "<<sum<<endl;
    return 0;
}