#include<iostream>
using namespace std;
void printcars(int cars[][5],int rowsize);
int main(){
    const int rowsize=5;
    const int colsize=5;
    int cars[rowsize][colsize]={{10,7,12,10,3},{12,23,45,2,45},{12,23,24,24,35},{12,34,89,9,8,},{1,2,3,4,5}};
    printcars(cars,rowsize);
}
void printcars(int cars[][5],int rowsize){
    for(int row=0;row<rowsize;row++){
        for(int col=0;col<5;col++){
            cout<<cars[row][col]<<"\t";
        }
        cout<<endl;
    }
}