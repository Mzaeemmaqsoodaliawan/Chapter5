#include<iostream>
using namespace std;
void printtoyota(int cars[][5],int rowsize);
 int  redcars(int cars[][5],int rowsize);
 void printnissan(int cars[][5],int rowsize);
int main(){
    const int rowsize=5;
    const int colsize=5;
    string colour[5]={"Red","Black","Brown","Blue","Grey"};
    int cars[rowsize][colsize]={{10,7,12,10,3},{12,23,45,2,45},{12,23,24,24,35},{12,34,89,9,8},{1,2,3,4,5}};
    printtoyota(cars,rowsize);
    redcars(cars,rowsize);
    printnissan(cars,rowsize);
}
void printtoyota(int cars[][5],int rowsize){
    int row=2;
        for(int col=0;col<5;col++){
           cout<<"The toyota cars are:"<<cars[row][col];
        cout<<endl;
    }}
    int  redcars(int cars[][5],int rowsize){
        int c=0;
        for(int row=0;row<5;row++){
        int col=0;
        c++;
    }
        cout<<"The number of red cars are:"<<c<<endl;;
        return c;
}  
void printnissan(int cars[][5],int rowsize){
    int row=3;
        for(int col=0;col<5;col++){
           cout<<"The  Nissancars are:"<<cars[row][col];
        cout<<endl;
    }}
    int convertor(string colour[5]){
        int choice,c;
        cout<<"Enter the colour of car you want to print:";
        cin>>choice;
        int x=int(colour[]);
        if(choice==x){
           for(int col=0;col<5;col++){
            c++;
            cout<<"The number of cars  of colour --you entered is "<<c<<endl;
        }}
    }
