#include<iostream>
using namespace std;
int main(){
    
    int r,sum=0;
    cout<<"Enter  row size:"<<endl;
    cin>>r;
    int arr[r][3];
    for(int i=0;i<r;i++){
        for(int j=0;j<3;j++){
            cout<<"Enter the Element in"<<i<<j<<endl;
            cin>>arr[i][j];
            sum=sum+arr[i][j];
        }
    }
    cout<<"The Total sum is "<<sum<<endl;
    return 0;
}