#include<iostream>
using namespace std;
int main(){
    string colour[5]={"Red","Black","Brown","Blue","Grey"};
    int carData[5][5]={{10,7,12,10,3},{12,23,45,2,45},{12,23,24,24,35},{12,34,89,9,8,},{1,2,3,4,5}};
    return 0;
 }