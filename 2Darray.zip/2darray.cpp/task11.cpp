#include <iostream>
using namespace std;

char grid[5][5];  // 5x5 grid
bool gravityStatus = true;  // Gravity is on by default
bool isBlackHole = true;  // Flag to enable/disable black hole behavior

// Function to display the grid
void DisplayWorld() {
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            if (grid[i][j] == ' ') {
                cout << "--- ";  // Print "---" for empty spaces
            } else {
                cout << grid[i][j] << " ";  // Print block (`#`) for filled spaces
            }
        }
        cout << endl;  // Newline after each row
    }
}

// Function to set the gravity status
void SetGravityStatus(bool status) {
    gravityStatus = status;
}

// Function to set the black hole status
void SetBlackHoleStatus(bool status) {
    isBlackHole = status;
}

// Function to simulate the effect of gravity (move blocks down)
void TimeTick() {
    if (!gravityStatus) return;  // If gravity is off, do nothing

    // Loop through each column to check for blocks that need to fall
    for (int col = 0; col < 5; col++) {
        for (int row = 3; row >= 0; row--) {  // Start from second-last row to the top
            if (grid[row][col] == '#') {
                int dropRow = row;
                // Find the lowest empty space below the block
                while (dropRow < 4 && grid[dropRow + 1][col] == ' ') {
                    dropRow++;
                }

                // If the last row is reached and it's a black hole, transport the block to the first row
                if (dropRow == 4 && isBlackHole) {
                    grid[0][col] = '#';  // Transport block to the first row
                    grid[row][col] = ' ';  // Clear the original spot
                }
                // Otherwise, move the block down if possible
                else if (dropRow != row) {
                    grid[dropRow][col] = '#';  // Move block down
                    grid[row][col] = ' ';      // Clear the previous spot
                }
            }
        }
    }
}

// Function to add a block at a specific position (for testing)
void AddBlock(int row, int col) {
    grid[row][col] = '#';  // Place block at (row, col)
}

int main() {
    // Initialize the grid with empty spaces
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            grid[i][j] = ' ';  // Initialize all cells with empty space
        }
    }

    // Add some blocks
    AddBlock(0, 0);
    AddBlock(1, 1);
    AddBlock(2, 2);
    AddBlock(3, 3);

    // Display initial world state
    cout << "Initial World:" << endl;
    DisplayWorld();
    cout << endl;

    // Activate gravity and simulate a tick
    SetGravityStatus(true);
    TimeTick();
    cout << "World after 1 time tick with gravity on and black hole:" << endl;
    DisplayWorld();
    cout << endl;

    // Deactivate gravity and simulate another tick (no change)
    SetGravityStatus(false);
    TimeTick();
    cout << "World after 1 time tick with gravity off (no change):" << endl;
    DisplayWorld();

    // Now turn off the black hole and test again
    SetBlackHoleStatus(false);
    cout << "World after 1 time tick with gravity on and no black hole:" << endl;
    TimeTick();
    DisplayWorld();

    return 0;
}

