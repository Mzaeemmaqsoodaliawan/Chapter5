#include<iostream>
using namespace std;
void lcf(int M[5][5]){
	int maxsum=-1,maxcolindex=0;
	for(int col=0;col<5;++col){
		int colsum=0;
		for(int row=0;row<5;++row){
			colsum+=M[row][col];
		}
		if(colsum>maxsum){
			maxsum=colsum;
			maxcolindex=col;
		}
	}
	for(int row=0;row<5;++row){
		int temp=M[row][0];
		M[row][0]=M[row][maxcolindex];
		M[row][maxcolindex]=temp;
	}
}
void printmatrix(int M[5][5]){
	for(int i=0;i<5;++i){
		for(int j=0;j<5;++j)
		cout<<M[i][j]<<" "; 
		cout<<endl;
	} 

} 
int main(){
	int M[5][5]={{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15},{16,17,18,19,20},{21,22,23,24,25}};
	cout<<"original Matrix:"<<endl;
	printmatrix(M);
	
	lcf(M);
	cout<<"Matrix after switching largest - sum column with first column:"<<endl;
	printmatrix(M);
	return 0;
}
