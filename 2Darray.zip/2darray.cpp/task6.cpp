#include<iostream>
#include<string>
using namespace std;
string fire(string coordinate){
    char grid[5][5]={
        '.','.','.','*','*'},{'.','*','.','.','.'},{'.','*','.','.','.'},{'.','*','.','.','.'}{'.','.','*','.','.'}};
     int col=0;
     if(coordinate[0]=='A')col=1;
     else if(coordinate[0]=='B')col=2;
     else if(coordinate[0]=='C')col=3;
     else if(coordinate[0]=='D')col=4;
     int row= coordinate[1]-'1';
     if(grid[row][col]=='*'){
        return "BOOM";
        }else {
            return "Splash";
        }
    int main(){
        cout<<fire("A1")<<endl;
        cout<<fire("D2")<<endl;
        return 0;
    }