#include <iostream>
using namespace std;


int fibonacci(int n) {
    if (n < 0)
     return -1;
    if (n == 0) 
    return 0;
    if (n == 1) 
    return 1;

    int a = 0, b = 1, next;

    for (int i = 2; i <= n; i++) {
        next = a + b;
        a = b;
        b = next;
    }
    return b;
}

int main() {
    int n;

    cout << "Enter a number: ";
    cin >> n;

    int result = fibonacci(n);

    if (result == -1)
        cout << "Invalid input!" << endl;
    else
        cout << "Fibonacci number at position " << n << " is: " << result << endl;

    return 0;
}
