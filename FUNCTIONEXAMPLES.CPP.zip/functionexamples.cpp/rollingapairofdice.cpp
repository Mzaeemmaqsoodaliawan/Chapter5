#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;


void rollDice(int &die1, int &die2) {
    die1 = rand() % 6 + 1;
    die2 = rand() % 6 + 1;
}

int main() {
    srand(time(0)); 

    int d1, d2;
    rollDice(d1, d2);

    cout << "You rolled: " << d1 << " and " << d2 << endl;
    cout << "Total: " << d1 + d2 << endl;

    return 0;
}

