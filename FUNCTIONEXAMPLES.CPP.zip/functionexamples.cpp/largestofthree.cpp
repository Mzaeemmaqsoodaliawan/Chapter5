#include<iostream>
using namespace std;
int Largest(int a,int b,int c)
{
    if(a>b&&a>c)
    return a;
    else if(b>a&&b>c)
    return b;
    else
    return c;
}
int main()
{
    int a,b,c;
    cout<<"Enter The Value of a,b,c:";
    cin>>a>>b>>c;
    int thelargest=Largest(a,b,c);
    cout<<"The Largest among a,b,c:"<<thelargest;
    return 0;
}