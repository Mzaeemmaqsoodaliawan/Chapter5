#include <iostream>
using namespace std;

// Function to calculate course grade
double courseGrade(double quiz, double assignment, double midterm, double finalExam) {
    double grade = (quiz * 0.10) +
                   (assignment * 0.20) +
                   (midterm * 0.30) +
                   (finalExam * 0.40);
    return grade;
}

int main() {
    double quiz, assignment, midterm, finalExam;

    cout << "Enter Quiz Marks (out of 100): ";
    cin >> quiz;

    cout << "Enter Assignment Marks (out of 100): ";
    cin >> assignment;

    cout << "Enter Midterm Marks (out of 100): ";
    cin >> midterm;

    cout << "Enter Final Exam Marks (out of 100): ";
    cin >> finalExam;

    double totalGrade = courseGrade(quiz, assignment, midterm, finalExam);

    cout << "Your Course Grade is: " << totalGrade << endl;

    return 0;
}
