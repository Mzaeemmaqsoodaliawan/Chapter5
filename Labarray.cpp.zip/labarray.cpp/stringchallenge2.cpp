#include <iostream>
using namespace std;

int main() {
    char word[50]; 

    cout << "Enter a word: ";
    cin >> word;  

    int k = 0;
    while (word[k] != '\0') { 
        if (word[k] >= 'a' && word[k] <= 'y') {
            word[k] = word[k] + 1;  
        }
        else if (word[k] == 'z') {
            word[k] = 'a'; 
        }
        else if (word[k] >= 'A' && word[k] <= 'Y') {
            word[k] = word[k] + 1;  
        }
        else if (word[k] == 'Z') {
            word[k] = 'A';  
        }
        k++; 
    }

    cout << "\nModified word: " << word << endl;
    return 0;
}
