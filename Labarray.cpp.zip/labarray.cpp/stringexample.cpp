#include<iostream>
using namespace std;
int main(){
    char pk[]="pakistan";
    cout<<pk;
    return 0;
}