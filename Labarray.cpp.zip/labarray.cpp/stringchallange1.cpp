#include<iostream>
using namespace std;
int main(){
    char pk[]="hello";
    cout<<pk[4];
    cout<<pk[3];
    cout<<pk[2];
    cout<<pk[1];
    cout<<pk[0];
}