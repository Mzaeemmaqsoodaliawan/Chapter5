#include<iostream>
using namespace std;
int main(){
    int array[5];
    array[0]=10;
    array[1]=20;
    array[2]=30;
    array[3]=40;
    array[4]=50;
    cout<<"1st element at location[0]="<<array[0]<<endl;
    cout<<"2nd element at location[1]="<<array[1]<<endl;
    cout<<"3rd element at location [2]="<<array[2]<<endl;
    cout<<"4rth element at location[3]="<<array[3]<<endl;
    cout<<"5th element at location[4]="<<array[4]<<endl;
    return 0;
}