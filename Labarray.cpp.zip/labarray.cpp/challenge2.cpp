#include<iostream>
using namespace std;
int main(){
    int array[10],smallest;
    for(int i=0;i<10;i++){
        cout<<"enter a number :";
        cin>>array[i];
    }smallest=array[0];
    for(int j=0;j<10;j++)
        if(smallest>array[j])
        
    
    smallest=array[j];
        cout<<"smallest is "<<smallest;
return 0;
}