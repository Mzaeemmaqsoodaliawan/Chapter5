#include <iostream>
#include <string>
using namespace std;

int main() {
    string words[8];  // array to store 8 words
    int totalVowels = 0;

    cout << "Enter 8 words: ";
    for (int i = 0; i < 8; i++) {
        cin >> words[i];  // input each word
    }

    cout << "\n--- Vowel Count ---\n";
    for (int i = 0; i < 8; i++) {
        int count = 0;
        for (int j = 0; j < words[i].length(); j++) {
            char ch = tolower(words[i][j]);
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                count++;
            }
        }
        cout << "Word " << i + 1 << " (" << words[i] << ") → " << count << " vowels\n";
        totalVowels += count;
    }

    cout << "\nTotal vowels in all 8 words: " << totalVowels << endl;
    return 0;
}

     

    
        
