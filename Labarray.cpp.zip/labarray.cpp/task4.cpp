#include<iostream>
using namespace std;
int main(){
    int number[5];
    cout<<"enter five numbers:"<<endl;
    for(int i=0;i<5;++i){
        cin>>number[i];
    }
    cout<<"the numbers are :";
    for(int n=0;n<5;++n){
        cout<<number[n]<<" ";
    }
    return 0;
}