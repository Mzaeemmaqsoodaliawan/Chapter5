#include<iostream>
using namespace std;
double circleArea(double radius)
{
    double area=3.14*radius*radius;
    return area;
}
int main(){
    double radius;
    cout<<"Enter The Radius:";
    cin>>radius;
   double area=circleArea(radius);
   cout<<"The Area:"<<area<<endl;
    return 0;
}