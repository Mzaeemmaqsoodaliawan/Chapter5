#include<iostream>
using namespace std;
int addNumbers(int a,int b)
{
    return a+b;
}
int main(){
    int a,b;
    cout<<"Enter The Numbers:";
    cin>>a>>b;
     int sum=addNumbers(a,b);
    cout<<"The Sum is:"<<sum<<endl;
    return 0;
}