#include<iostream>
using namespace std;
void timesTen(int number)
{
    int result=number*10;
    cout<<"Result:"<<result<<endl;
}
int main(){
    int number;
    cout<<"Enter a number:";
    cin>>number;
    timesTen(number);
    return 0;
}