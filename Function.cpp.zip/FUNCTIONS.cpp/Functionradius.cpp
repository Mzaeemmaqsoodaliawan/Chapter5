#include<iostream>
using namespace std;
double getRadius()
{
    double r;
    cout<<"Enter the Radius:";
    cin>>r;
    return r;
}
int main()
{
 double radius=getRadius();
 cout<<"The Radius is:"<<radius<<endl;
return 0;
}