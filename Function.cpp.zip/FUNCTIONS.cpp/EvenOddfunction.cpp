#include<iostream>
using namespace std;
bool isEven(int num){
    if(num%2==0)
    return true;
    else
    return false;
}
int main()
{
    int num;
    cout<<"enter a number:";
    cin>>num;
    bool result=isEven(num);
   cout<<"The Result is:"<<result;
    return 0;
}
