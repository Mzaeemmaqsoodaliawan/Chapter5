#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>

using namespace std;

int main() {
    cout << "Program started...\n"; // test line

    const int countries = 12;
    const int products = 5;
    const int transportModes = 3;
    const int tariffRates = 12;
    const int months = 12;

    srand(time(0));

    int globalTrade[countries][countries][products][transportModes][tariffRates][months];
    int tariffPercent[countries][countries][products][transportModes][tariffRates][months];

    for (int o = 0; o < countries; o++)
        for (int d = 0; d < countries; d++)
            for (int p = 0; p < products; p++)
                for (int m = 0; m < transportModes; m++)
                    for (int t = 0; t < tariffRates; t++)
                        for (int month = 0; month < months; month++) {
                            globalTrade[o][d][p][m][t][month] = 30000 + rand() % (120001 - 30000);
                            tariffPercent[o][d][p][m][t][month] = rand() % 101;
                        }

    const int slabs = 5;
    int originSlabCount[countries][slabs] = {0};

    for (int o = 0; o < countries; o++)
        for (int d = 0; d < countries; d++)
            for (int p = 0; p < products; p++)
                for (int m = 0; m < transportModes; m++)
                    for (int t = 0; t < tariffRates; t++)
                        for (int month = 0; month < months; month++) {
                            int slab = tariffPercent[o][d][p][m][t][month] / 20;
                            if (slab > 4) slab = 4;
                            originSlabCount[o][slab]++;
                        }

    cout << "\nOrigin Country-wise Trade Counts per Tariff Slab (0-19%,20-39%,...80-100%)\n\n";
    cout << setw(12) << "Origin";
    for (int s = 0; s < slabs; s++)
        cout << setw(12) << "Slab" << s;
    cout << endl;

    for (int o = 0; o < countries; o++) {
        cout << setw(12) << "Country" << o;
        for (int s = 0; s < slabs; s++)
            cout << setw(12) << originSlabCount[o][s];
        cout << endl;
    }

    cout << "\nPress Enter to exit...";
    cin.get(); // pause
    return 0;
}
