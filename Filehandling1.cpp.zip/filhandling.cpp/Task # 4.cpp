#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ofstream pgm("strips2.pgm");

    // PGM Header
    pgm << "P2\n";
    pgm << "256 256\n";
    pgm << "15\n";

    // Image data
    for (int i = 0; i < 256; i++)
    {
        int value = i / 16;   // changes every 16 lines (0 to 15)

        for (int j = 0; j < 256; j++)
        {
            pgm << value << " ";
        }
        pgm << endl;
    }

    pgm.close();

    cout << "PGM file strips2.pgm created successfully.\n";
    return 0;
}
