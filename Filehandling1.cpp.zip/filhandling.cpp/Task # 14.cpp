#include <iostream>
#include <cstdlib>   // rand()
#include <ctime>     // time()
#include <iomanip>   // setw()

using namespace std;

int main() {
    const int countries = 12;
    const int products = 5;
    const int transportModes = 3;
    const int tariffRates = 4;
    const int months = 12;

    // Seed random number generator
    srand(time(0));

    // Declare 6D array: Origin x Destination x Product x Mode x Tariff x Month
    int globalTrade[countries][countries][products][transportModes][tariffRates][months];

    // Fill array with random values between 30,000 and 120,000
    for (int origin = 0; origin < countries; origin++) {
        for (int dest = 0; dest < countries; dest++) {
            for (int product = 0; product < products; product++) {
                for (int mode = 0; mode < transportModes; mode++) {
                    for (int tariff = 0; tariff < tariffRates; tariff++) {
                        for (int month = 0; month < months; month++) {
                            globalTrade[origin][dest][product][mode][tariff][month] =
                                30000 + rand() % (120001 - 30000); // 30k to 120k
                        }
                    }
                }
            }
        }
    }

    // Compute month-wise average trade
    cout << "\nMonth-wise Average Trade:\n";
    cout << fixed << setprecision(2);

    for (int month = 0; month < months; month++) {
        long long sum = 0;
        long long count = 0; // number of entries summed

        for (int origin = 0; origin < countries; origin++) {
            for (int dest = 0; dest < countries; dest++) {
                for (int product = 0; product < products; product++) {
                    for (int mode = 0; mode < transportModes; mode++) {
                        for (int tariff = 0; tariff < tariffRates; tariff++) {
                            sum += globalTrade[origin][dest][product][mode][tariff][month];
                            count++;
                        }
                    }
                }
            }
        }

        double average = static_cast<double>(sum) / count;
        cout << "Month " << (month + 1) << ": " << average << endl;
    }

    return 0;
}
