#include <iostream>
#include <fstream>
#include <cstdlib>  // For rand()
#include <ctime>    // For time()

using namespace std;

int main() {
    ofstream file("pattern_sample.pgm");

    if (!file) {
        cout << "Error creating file!" << endl;
        return 1;
    }

    int width = 200;
    int height = 200;
    int max_gray = 255;

    // Seed random generator
    srand(time(0));

    // Write PGM header
    file << "P2" << endl;
    file << width << " " << height << endl;
    file << max_gray << endl;

    int numbersPerLine = 20; // Like your sample, 20 numbers per line

    // Generate pixel data
    for (int row = 0; row < height; row++) {
        int count = 0;
        for (int col = 0; col < width; col++) {
            int pixelValue = rand() % 256; // Value between 0 and 255
            file << pixelValue << " ";
            count++;

            // Break line after 20 numbers (like sample)
            if (count == numbersPerLine) {
                file << endl;
                count = 0;
            }
        }
        // Ensure line ends after row
        if (count != 0)
            file << endl;
    }

    file.close();
    cout << "File pattern_sample.pgm created successfully!" << endl;
    return 0;
}
