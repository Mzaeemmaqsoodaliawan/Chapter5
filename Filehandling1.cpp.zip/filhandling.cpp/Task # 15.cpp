#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    const int n = 20;
    double numbers[n]; // array to store 20 numbers

    cout << "Enter 20 numbers (decimals allowed, separated by spaces or newlines):\n";

    // Read 20 numbers from user
    for (int i = 0; i < n; i++) {
        cin >> numbers[i];
    }

    // Compute average
    double sum = 0;
    for (int i = 0; i < n; i++)
        sum += numbers[i];
    
    double average = sum / n;

    cout << fixed << setprecision(2);
    cout << "\nAverage of the 20 numbers: " << average << endl;

    // Display numbers above average
    cout << "Numbers above the average:\n";
    for (int i = 0; i < n; i++) {
        if (numbers[i] > average)
            cout << numbers[i] << "  ";
    }
    cout << endl;

    return 0;
}
