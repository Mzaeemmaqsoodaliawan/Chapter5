#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ofstream file("pattern2.pgm");

    if (!file)
    {
        cout << "Error creating file!" << endl;
        return 1;
    }

    // PGM header
    file << "P2" << endl;
    file << "256 256" << endl;
    file << "255" << endl;

    // Generate 16x16 checkerboard
    for (int row = 0; row < 256; row++)
    {
        for (int col = 0; col < 256; col++)
        {
            int squareRow = row / 16;
            int squareCol = col / 16;

            int pixelValue;
            if ((squareRow + squareCol) % 2 == 0)
                pixelValue = 0;     // black
            else
                pixelValue = 255;   // white

            file << pixelValue << " ";
        }
        file << endl;
    }

    file.close();
    cout << "File pattern2.pgm created successfully!" << endl;

    return 0;
}
