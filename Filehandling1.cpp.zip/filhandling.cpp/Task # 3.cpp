#include<iostream>
#include<fstream>
using namespace std;
int main(){
    ofstream pgm("strips1.pgm");
    pgm<<"p2\n";
    pgm<<"256 256\n";
    pgm<<"3\n";
    for(int i=0;i<256;i++){
        int value;
        if (i<64)
        {
            value=2;
        } else if (i<128)
        {
            value=0;
        }else if (i<192)
        {
            value=3;
        }else 
        value=1;
        for (int j = 0; j < 256; j++)
        {
            pgm<<value<<" ";
        }
        pgm<<endl;
    }
    pgm.close();
    cout<<"PGM file created successfully."<<endl;
    return 0;
}
