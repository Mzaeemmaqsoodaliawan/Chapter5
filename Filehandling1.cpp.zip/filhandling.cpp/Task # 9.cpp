#include <iostream>
#include <fstream>

using namespace std;

int main() {
    ofstream file("pattern4.ppm");

    if (!file) {
        cout << "Error creating file!" << endl;
        return 1;
    }

    // PPM header
    file << "P3" << endl;
    file << "256 256" << endl;
    file << "255" << endl;

    // Generate 16x16 checkerboard
    for (int row = 0; row < 256; row++) {
        for (int col = 0; col < 256; col++) {
            int squareRow = row / 16;
            int squareCol = col / 16;

            int pixelValue;
            if ((squareRow + squareCol) % 2 == 0)
                pixelValue = 0;    // black
            else
                pixelValue = 255;  // white

            // P3 format: R G B (same value for grayscale)
            file << pixelValue << " " << pixelValue << " " << pixelValue << " ";
        }
        file << endl;
    }

    file.close();
    cout << "File pattern4.ppm created successfully!" << endl;

    return 0;
}
