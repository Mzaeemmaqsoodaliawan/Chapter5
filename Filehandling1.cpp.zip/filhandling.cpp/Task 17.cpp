#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ofstream file("pattern1.pgm");

    if (!file)
    {
        cout << "Error creating file!" << endl;
        return 1;
    }

    // PGM header
    file << "P2" << endl;
    file << "256 256" << endl;
    file << "255" << endl;

    // Generate pixel data
    for (int row = 0; row < 256; row++)
    {
        for (int col = 0; col < 256; col++)
        {
            file << (row + col) % 255 << " ";
        }
        file << endl;
    }

    file.close();
    cout << "File pattern1.pgm created successfully!" << endl;

    return 0;
}
