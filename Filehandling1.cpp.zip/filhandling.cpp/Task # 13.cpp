#include <iostream>
#include <cstdlib>   // For rand()
#include <ctime>     // For time()
#include <iomanip>   // For setw()

using namespace std;

int main() {
    const int countries = 12;
    const int products = 5;
    const int transportModes = 3;
    const int tariffRates = 4;
    const int months = 12;

    // Seed random number generator
    srand(time(0));

    // Declare 6D array: Origin x Destination x Product x Mode x Tariff x Month
    int globalTrade[countries][countries][products][transportModes][tariffRates][months];

    // Fill array with random values between 30,000 and 120,000
    for (int origin = 0; origin < countries; origin++) {
        for (int dest = 0; dest < countries; dest++) {
            for (int product = 0; product < products; product++) {
                for (int mode = 0; mode < transportModes; mode++) {
                    for (int tariff = 0; tariff < tariffRates; tariff++) {
                        for (int month = 0; month < months; month++) {
                            globalTrade[origin][dest][product][mode][tariff][month] =
                                30000 + rand() % (120001 - 30000); // random between 30k-120k
                        }
                    }
                }
            }
        }
    }

    // Compute country-to-country total trade (sum all other dimensions)
    int totalTrade[countries][countries] = {0};

    for (int origin = 0; origin < countries; origin++) {
        for (int dest = 0; dest < countries; dest++) {
            if (origin == dest) continue; // Diagonal will remain 0 for now
            int sum = 0;
            for (int product = 0; product < products; product++) {
                for (int mode = 0; mode < transportModes; mode++) {
                    for (int tariff = 0; tariff < tariffRates; tariff++) {
                        for (int month = 0; month < months; month++) {
                            sum += globalTrade[origin][dest][product][mode][tariff][month];
                        }
                    }
                }
            }
            totalTrade[origin][dest] = sum;
        }
    }

    // Display country-to-country trade matrix
    cout << "\nCountry-to-Country Total Trade Matrix (diagonal left blank):\n\n";

    cout << setw(8) << " ";
    for (int dest = 0; dest < countries; dest++) {
        cout << setw(12) << "C" << dest;
    }
    cout << endl;

    for (int origin = 0; origin < countries; origin++) {
        cout << setw(8) << "C" << origin;
        for (int dest = 0; dest < countries; dest++) {
            if (origin == dest)
                cout << setw(12) << " "; // diagonal blank
            else
                cout << setw(12) << totalTrade[origin][dest];
        }
        cout << endl;
    }

    return 0;
}
