#include<iostream>
#include<fstream>
using namespace std;
int main()
{
    int n;
    string code,name,status;
    int credit,semester;
    ofstream file1("courses.csv");
    ofstream file2("courses.txt");
    cout<<"Enter  number of courses:";
    cin>>n;
    cin.ignore();
    for(int i=1;i<=n;i++){
        cout<<"\n Courses "<<i<<endl;
        cout<<"course code:";
        getline(cin,code);
        cout<<"course name:";
        getline(cin,name);
        cout<<"Credit Hours:";
        cin>>credit;
        cout<<"Semester";
        cin>>semester;
        cin.ignore();
        cout<<"Status(Activated/disactivated):";
        getline(cin,status);
        file1 << code << "," << name << "," << credit << "," << semester << "," << status << endl;
        file2 << code << " " << name << " " 
        << credit << " " << semester << " " << status << endl;
    }
    file1.close();
    file2.close();
    cout<<"\n File Created successfully:";
    return 0;
}