#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

int main() {
    string inputFile = "pattern_sample.pgm";        // Your input PGM file
    string outputFile = "pattern_sample_inverted.pgm"; // Output file

    ifstream inFile(inputFile);
    ofstream outFile(outputFile);

    if (!inFile) {
        cout << "Error: Cannot open input file '" << inputFile << "'!" << endl;
        return 1;
    }
    if (!outFile) {
        cout << "Error: Cannot create output file '" << outputFile << "'!" << endl;
        return 1;
    }

    string header[3];

    // Read and write header
    for (int i = 0; i < 3; i++) {
        getline(inFile, header[i]);
        outFile << header[i] << endl;
    }

    // Get max gray value (usually 255)
    int maxGray;
    istringstream(header[2]) >> maxGray;

    string line;
    // Process pixel values
    while (getline(inFile, line)) {
        if (line.empty()) continue; // Skip blank lines
        istringstream iss(line);
        int pixel;
        while (iss >> pixel) {
            int invertedPixel = maxGray - pixel;
            outFile << invertedPixel << " ";
        }
        outFile << endl;
    }

    inFile.close();
    outFile.close();

    cout << "File '" << outputFile << "' created successfully!" << endl;
    cout << "Open it in Notepad to see numbers or IrfanView to see the inverted image." << endl;

    return 0;
}
