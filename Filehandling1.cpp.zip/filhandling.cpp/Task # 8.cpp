#include <iostream>
#include <fstream>

using namespace std;

int main() {
    ofstream file("pattern3.pgm");

    if (!file) {
        cout << "Error creating file!" << endl;
        return 1;
    }

    // PGM header
    file << "P2" << endl;
    file << "256 256" << endl;
    file << "255" << endl;

    // Generate 8x8 chessboard
    for (int row = 0; row < 256; row++) {
        for (int col = 0; col < 256; col++) {
            int squareRow = row / 32;
            int squareCol = col / 32;

            int pixelValue;
            if ((squareRow + squareCol) % 2 == 0)
                pixelValue = 20;    // near 0 (black)
            else
                pixelValue = 235;   // near 255 (white)

            file << pixelValue << " ";
        }
        file << endl;
    }

    file.close();
    cout << "File pattern3.pgm created successfully!" << endl;

    return 0;
}
