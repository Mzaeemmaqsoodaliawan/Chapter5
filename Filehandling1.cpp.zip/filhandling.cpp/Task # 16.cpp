#include <iostream>
#include <iomanip>
#include <cmath> // for round()

using namespace std;

// Arrays for words
string one[] = {"", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
string two[] = {"", "ten", "eleven", "twelve", "thirteen", "fourteen",
                "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"};
string tens[] = {"", "", "twenty", "thirty", "forty", "fifty",
                 "sixty", "seventy", "eighty", "ninety"};
string scales[] = {"", "thousand", "lakh", "crore"};

// Convert 1-999 to words
string convertThreeDigit(int num) {
    string word = "";
    int h = num / 100;
    int rem = num % 100;

    if (h > 0) word += one[h] + " hundred";

    if (rem > 0) {
        if (!word.empty()) word += " and ";
        if (rem < 10)
            word += one[rem];
        else if (rem < 20)
            word += two[rem - 9];
        else {
            int t = rem / 10;
            int u = rem % 10;
            word += tens[t];
            if (u > 0) word += " " + one[u];
        }
    }
    return word;
}

// Convert integer part to words (Indian numbering)
string numberToWords(long long num) {
    if (num == 0) return "zero";

    string result = "";
    int idx = 0;

    while (num > 0) {
        int part = 0;
        if (idx == 0)
            part = num % 1000;       // units, hundreds
        else
            part = num % 100;        // rest two digits for thousands/lacs/crores

        if (part != 0) {
            string s = convertThreeDigit(part);
            if (!scales[idx].empty()) s += " " + scales[idx];
            if (!result.empty()) result = s + " " + result;
            else result = s;
        }

        num = (idx == 0) ? num / 1000 : num / 100;
        idx++;
    }

    return result;
}

// Convert a floating number to words (rupees and paisa)
string convertNumberToWords(double num) {
    long long rupees = static_cast<long long>(num);
    int paisa = round((num - rupees) * 100);

    string words = "";
    words += numberToWords(rupees) + " rupees";

    if (paisa > 0) {
        words += " and " + numberToWords(paisa) + " paisa";
    }

    return words;
}

int main() {
    const int n = 20;
    double numbers[n];

    cout << "Enter 20 numbers (like 12, 32, 456.65):\n";

    // Read 20 numbers (can use input redirection)
    for (int i = 0; i < n; i++) {
        cin >> numbers[i];
    }

    // Display numbers in words
    cout << "\nNumbers in words:\n";
    for (int i = 0; i < n; i++) {
        cout << i+1 << ": " << convertNumberToWords(numbers[i]) << endl;
    }

    return 0;
}
