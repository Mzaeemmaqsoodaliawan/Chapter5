#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ofstream pgm("strips3.pgm");

    pgm << "P2\n";
    pgm << "256 256\n";
    pgm << "255\n";

    for (int i = 0; i < 256; i++)
    {
        int value = i;   // 0 to 255 (valid for max 255)

        for (int j = 0; j < 256; j++)
        {
            pgm << value << " ";
        }
        pgm << endl;
    }

    pgm.close();
    cout << "strips3.pgm created successfully\n";
    return 0;
}
