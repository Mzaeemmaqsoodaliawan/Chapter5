#include<iostream>
using namespace std;

int main()
{
    int amplify,a;
    cout<<"enter the last bound:";
    cin>>amplify;
    int i=1;
    while(i<=amplify) 
    {
        if(i%4==0) 
        {
            a=i*10;
            cout<<a<<",";
        i++; 
    }
    else 
    {
            cout<<i<<",";
            i++;
        }
    } 
    
    return 0;
}