#include <iostream>
using namespace std;

int main() {
    int num, count;
    int count2 = 0, count3 = 0, count4 = 0;

    cout << "Enter how many numbers you will input: ";
    cin >> count;

    for (int i = 0; i < count; i++) {
        cout << "Enter a value: ";
        cin >> num;

        if (num % 2 == 0)
            count2++;
        if (num % 3 == 0)
            count3++;
        if (num % 4 == 0)
            count4++;
    }

    float p1 = (float(count2) / count) * 100;
    float p2 = (float(count3) / count) * 100;
    float p3 = (float(count4) / count) * 100;

    cout << "Percentage of numbers divisible by 2: " << p1 << "%" << endl;
    cout << "Percentage of numbers divisible by 3: " << p2 << "%" << endl;
    cout << "Percentage of numbers divisible by 4: " << p3 << "%" << endl;

    return 0;
}
