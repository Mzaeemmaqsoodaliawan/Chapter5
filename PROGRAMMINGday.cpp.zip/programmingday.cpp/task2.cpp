#include<iostream>
using namespace std;
int main()
{
    int n;
    long long dots;
    cout<<"enter the number of triangle:";
    cin>>n;
    dots=n*(n+1)/2;
    cout<<"triangle("<<n<<") = "<<dots<<endl;
    return 0;
}