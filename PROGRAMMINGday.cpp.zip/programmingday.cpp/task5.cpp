#include<iostream>
#include<iomanip>
using namespace std;
int main(){
    int cargo,count,tons;
    double total_cost=0,tons_by_minibus=0,tons_by_truck=0, tons_by_train=0,per_train;
    double avg_price,per_truck,per_minibus,total_tons=0;
    cout<<"enter  the range of current cargo:";
    cin>>cargo;
    for(int i=1;i<=cargo;i++)
    {  
    cout<<"enter the tonnage:";
    cin>>tons;
    total_tons+=tons;
    if(tons<=3)
    {  tons_by_minibus+=tons;
        total_cost+=(tons*200.0);
    }else if( tons<=11){
        tons_by_truck+=tons;
        total_cost+=(tons*175.0);
    }else {  tons_by_train+=tons;
         total_cost+=(tons*120.0);
    }   
    }avg_price=total_cost/total_tons;
per_minibus=(tons_by_minibus/total_tons)*100.0;
per_truck=(tons_by_truck/  total_tons)*100.0;
per_train=(tons_by_train/ total_tons)*100.0;
cout<<fixed<<setprecision(2);
cout<<"avg price:"<<avg_price;
cout<<endl;
cout<<"per_minibus"<<per_minibus<<"%";
cout<<endl;
    cout<<"per_truck:"<<per_truck<<"%";
cout<<endl;
    cout<<"per_train:"<<per_train<<"%";
 return 0;   
}