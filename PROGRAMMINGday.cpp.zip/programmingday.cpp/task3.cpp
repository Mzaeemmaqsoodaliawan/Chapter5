#include<iostream>
using namespace std;
int main(){
    int doctor,total_patient;
    int total_untreated=0,total_treated=0,days;
    int treated_patient=0,untreated_patient=0;
    doctor=7;int a=0;
    cout<<"enter no of days:";
    cin>>days;
    int i=1;
do 
    {
    
         int total_patient;
        cout<<"Enter no of patients came hospital:";
        cin>>total_patient; 
        if(total_patient<=doctor)
        {
        untreated_patient=a;
            treated_patient=total_patient;
    }
        else
 total_treated+=treated_patient;
            total_untreated+=untreated_patient;
            cout<<"days"<<i<<": treated_patient"<<treated_patient;
            cout<<endl;
            cout<<"  untreated_patient:"<<untreated_patient;
            cout<<endl;
       
      
           if(i%3==0) {
            total_treated+=treated_patient;
            cout<<"total_treated:"<<total_treated;
            cout<<endl;
            total_untreated+=untreated_patient;
            cout<<"total_untreated:"<<total_untreated;
            cout<<endl;
        if(untreated_patient>treated_patient)
            
               doctor++;
              cout<<"a new doctor has been added:"<<doctor;
              
         } i++;
    }while(i<=days);
    return 0;
}